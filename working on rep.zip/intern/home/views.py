from django.shortcuts import render,HttpResponse
import pandas as pd
import csv
from django.contrib import messages

def display_merged_dataset(request):
    return render(request, 'display.html')
def merge_datasets(request):
    try:
        
        if request.method == 'POST':
            csv_file1 = request.FILES.get('csv_file1')
            csv_file2 = request.FILES.get('csv_file2')
            merge_type = request.POST.get('merge_type')
            merge = request.POST.get('merge')
            
            if not csv_file1 or not csv_file2:
                messages.error(request, 'Please select both csv files')
                return render(request, 'messages.html')
            elif not merge_type:
                messages.error(request, 'Please select merge type')
                return render(request, 'messages.html')
            else:
                df1 = pd.read_csv(csv_file1)
                df2 = pd.read_csv(csv_file2)
                df1.columns = df1.columns
                if merge_type == 'inner' and merge == 'default':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='inner')
                elif merge_type == 'left' and merge == 'default':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='left')
                elif merge_type == 'right' and merge == 'default':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='right')
                elif merge_type == 'outer' and merge == 'default':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='outer')
                elif merge_type == 'concat' and merge == 'default':
                    df_merged = pd.concat([df1,df2],axis=1)
                elif merge_type == 'inner'and merge == 'one_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='inner', validate="one_to_one")
                elif merge_type == 'left' and merge == 'one_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='left', validate="one_to_one")
                elif merge_type == 'right' and merge == 'one_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='right', validate="one_to_one")
                elif merge_type == 'outer' and merge == 'one_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='outer', validate="one_to_one")
                elif merge_type == 'concat' and merge == 'one_to_one':
                    df_merged = pd.concat([df1,df2],axis=1)
                elif merge_type == 'inner'and merge == 'many_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='inner', validate="many_to_one")
                elif merge_type == 'left' and merge == 'many_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='left', validate="many_to_one")
                elif merge_type == 'right' and merge == 'many_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='right', validate="many_to_one")
                elif merge_type == 'outer' and merge == 'many_to_one':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='outer', validate="many_to_one")
                elif merge_type == 'concat' and merge == 'many_to_one':
                    df_merged = pd.concat([df1,df2],axis=1)
                elif merge_type == 'inner'and merge == 'many_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='inner', validate="many_to_many")
                elif merge_type == 'left' and merge == 'many_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='left', validate="many_to_many")
                elif merge_type == 'right' and merge == 'many_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='right', validate="many_to_many")
                elif merge_type == 'outer' and merge == 'many_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='outer', validate="many_to_many")
                elif merge_type == 'concat' and merge == 'many_to_many':
                    df_merged = pd.concat([df1,df2],axis=1)
                elif merge_type == 'inner'and merge == 'one_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='inner', validate="one_to_many")
                elif merge_type == 'left' and merge == 'one_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='left', validate="one_to_many")
                elif merge_type == 'right' and merge == 'one_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='right', validate="one_to_many")
                elif merge_type == 'outer' and merge == 'one_to_many':
                    df_merged = pd.merge(df1, df2,on = ['on1','on2'], how='outer', validate="one_to_many")
                elif merge_type == 'concat' and merge == 'one_to_many':
                    df_merged = pd.concat([df1,df2],axis=1)
                else:
                    messages.error(request, 'Invalid')
                    return render(request, 'messages.html')
                response = HttpResponse(content_type='text/csv')
                response['Content-Disposition'] = 'attachment; filename="merged_dataset.csv"'
                df_merged.to_csv(response)
                return response
        
            
    except Exception as e:
    # handle the exception
        print(f"An error occurred while merging the datasets: {e}")
    return render(request, 'final.html') 


