from django.contrib import admin
from django.urls import path
from . import views

app_name = 'merge_csv'

urlpatterns = [
    path('', views.merge_datasets, name='merge_csv'),
    path('display_merged_dataset/', views.display_merged_dataset, name='display_merged_dataset'),
    
]
